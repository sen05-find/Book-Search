import React from 'd:/s2/perancangan web/React/firtsproject/node_modules/@types/react/index';
import ReactDOM from 'd:/s2/perancangan web/React/firtsproject/node_modules/@types/react-dom/client';
import Catalog from 'd:/s2/perancangan web/React/firtsproject/src/Catalog';
import reportWebVitals from 'd:/s2/perancangan web/React/firtsproject/src/reportWebVitals';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <div className="container py-3">
      <h2 className="pb-2 mb-4 border-bottom">Populer</h2>
      <div class="row">
        <Catalog />
      </div>
    </div>
    <div className="container py-3">
      <h2 className="pb-2 mb-4 border-bottom">Our Books</h2>
      <div className="row">
        <Catalog />
      </div>
    </div>
  </React.StrictMode>
); 
reportWebVitals();